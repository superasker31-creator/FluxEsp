package com.esp.mixin;

import com.esp.EspClient;
import com.esp.util.TargetEspRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderWorld(MatrixStack matrices, float tickDelta, long limitTime, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightmapTextureManager lightmapTextureManager, Matrix4f projectionMatrix, CallbackInfo ci) {
        LivingEntity hedef = EspClient.sonHedef;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (hedef != null && hedef.isAlive() && mc.player != null) {
            Vec3d kameraPozisyonu = camera.getPos();
            
            // Hedef hareket ederken çizgi titremesin diye koordinatları eşitliyoruz
            double x = hedef.prevX + (hedef.getX() - hedef.prevX) * tickDelta - kameraPozisyonu.x;
            double y = hedef.prevY + (hedef.getY() - hedef.prevY) * tickDelta - kameraPozisyonu.y;
            double z = hedef.prevZ + (hedef.getZ() - hedef.prevZ) * tickDelta - kameraPozisyonu.z;

            float sure = mc.player.age + tickDelta;
            double yaricap = hedef.getWidth() * 0.8;

            TargetEspRenderer.daireCiz(matrices, x, y, z, yaricap, sure);
        }
    }
}
