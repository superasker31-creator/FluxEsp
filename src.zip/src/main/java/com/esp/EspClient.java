package com.esp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class EspClient implements ClientModInitializer {
    // Vurduğumuz son düşmanı hafızada tutan değişken
    public static LivingEntity sonHedef = null;

    @Override
    public void onInitializeClient() {
        // Her oyun tick'inde (anında) tetiklenen döngü
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Eğer oyuncu saldırma tuşuna basıyorsa ve crosshair bir varlığın üzerindeyse
            if (client.options.attackKey.isPressed() && client.crosshairTarget != null && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity entity = ((EntityHitResult) client.crosshairTarget).getEntity();
                
                // Vurulan şey canlı bir varlıksa (Zombi, oyuncu, hayvan vb.) hedef olarak kaydet
                if (entity instanceof LivingEntity) {
                    sonHedef = (LivingEntity) entity;
                }
            }

            // Eğer hedefteki varlık öldüyse çizgiyi/halkayı ekrandan kaldır
            if (sonHedef != null && !sonHedef.isAlive()) {
                sonHedef = null;
            }
        });
    }
}
