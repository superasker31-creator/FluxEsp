package com.esp.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

public class TargetEspRenderer {

    public static void daireCiz(MatrixStack matrices, double x, double y, double z, double yaricap, float sure) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        matrices.push();
        matrices.translate(x, y + 0.05, z);
        
        // Halkanın dönme hızı
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sure * 2.0f));

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buffer = tessellator.getBuffer();
        
        buffer.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);

        // 32 adet çizgiyi birleştirip yuvarlak yapıyoruz
        int noktalar = 32;
        for (int i = 0; i <= noktalar; i++) {
            double aci = (i * 2 * Math.PI) / noktalar;
            float cx = (float) (Math.cos(aci) * yaricap);
            float cz = (float) (Math.sin(aci) * yaricap);

            // Buradaki (255, 0, 0, 255) Kırmızı renktir. Değiştirebilirsin.
            buffer.vertex(matrix, cx, 0, cz).color(255, 0, 0, 255).next();
        }

        tessellator.draw();
        matrices.pop();

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
